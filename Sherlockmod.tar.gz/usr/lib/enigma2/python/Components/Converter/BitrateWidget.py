from enigma import eLabel, eTimer
from Components.Renderer.Renderer import Renderer
from Components.VariableText import VariableText

# محاولة استيراد eBitrateCalculator
try:
    from bitratecalc import eBitrateCalculator
    HAS_BITRATECALC = True
except ImportError:
    HAS_BITRATECALC = False

class BitrateWidget(Renderer, VariableText):
    def __init__(self):
        Renderer.__init__(self)
        VariableText.__init__(self)
        self.bitratecalc = None
        self.mode = "both"
        self.format = "V:{vcur} A:{acur}"
        self.updateTimer = eTimer()
        self.updateTimer.callback.append(self.updateBitrate)

    def applySkin(self, desktop, parent):
        attribs = []
        for (attrib, value) in self.skinAttributes or []:
            if attrib == "mode":
                self.mode = value.strip().lower()
            elif attrib == "format":
                self.format = value
            else:
                attribs.append((attrib, value))
        self.skinAttributes = attribs
        return Renderer.applySkin(self, desktop, parent)

    def changed(self, what):
        if what[0] != self.CHANGED_CLEAR:
            if HAS_BITRATECALC and self.bitratecalc is None:
                # adapter=0, demux=0 (سيتم تحديثها تلقائياً)
                self.bitratecalc = eBitrateCalculator(0, 0, 0, 0)
            if self.bitratecalc:
                self.bitratecalc.start()
                self.updateTimer.start(900, False)  # تحديث كل 0.9 ثانية

    def updateBitrate(self):
        if not self.instance:
            return

        if not HAS_BITRATECALC or not self.bitratecalc:
            self.setText("Bitrate: غير مدعوم")
            return

        try:
            vcur = self.bitratecalc.getVideoBitrate() // 1000
            acur = self.bitratecalc.getAudioBitrate() // 1000

            if self.mode == "video":
                text = f"Video: {vcur}"
            elif self.mode == "audio":
                text = f"Audio: {acur}"
            else:
                text = self.format.format(vcur=vcur or 0, acur=acur or 0)
        except:
            text = "V:0 A:0"

        self.setText(text + " kbps")

    def onShow(self):
        if self.bitratecalc:
            self.bitratecalc.start()
            self.updateTimer.start(900, False)

    def onHide(self):
        if self.bitratecalc:
            self.bitratecalc.stop()
        self.updateTimer.stop()