# -*- coding: utf-8 -*-
# Sherlockmod Mod v1.4.4 - Full Source Protection (3.13/3.14)

import base64, zlib, sys

def triple_xor_decrypt(data, key3):
    key1 = 0x5A
    key2 = 0x37
    data = bytes(b ^ key3 for b in data)
    data = bytes(b ^ key2 for b in data)
    data = bytes(b ^ key1 for b in data)
    return data

try:
    data = base64.b64decode("PJ5FbUGSvjyeyREP1u9yUNk/URD7zX+wL4iDnPjuWtzLdcJCX8jJXaBRO4CDuEBCktRpIDcdDSwz1o7vYBElZDDqitHq4JZ9G9TrezkB+IZD86xfloa0r75ndr/GxNZ0WMzcXehZoPm01co+GWQb1SnfIcwV8PFTZMP+xMVDBTUHoqBvCiYXB3mLImRrz15m6pdAcLHGyF00G9QiLCJ3e0xVHMd2T/qzAbmZS/g+bKWYM+S3xuCFBHo732WXczE1oEkdsI+J29w8JDaxhFtNVzJDXHA3U7291c/AAcn8TPx5wtu71wy4G2a6K4B+xCm5XdyJJHk4v2W59aET0+Li6VE6dDsuHCHb6yXubl+H8lM4VS9Wjd5NAZ/6OqnzSq5g5hBp84WuXlDYpHHf+Woa0ojaSTzdsQJmfyXRjPt3ZVdBKB33QDV4ydw7xaWFaYiAJ1CIKWjB8J+pumQx/uRfSXz57ypMvHEvWtD3ZwWQna8+0J6ATa8H62lm+GgGc3+WtjCt32WYWtkCGrz/9de8HzYwCBwGKy02c0OzKHA1yWlxJMAy6pnFYxAMpRhaWNjHYvAeUdl1klHxENJTFjWHaBGXPtArAZgMgq5sasHesV35HMmJ+RFOKFfh58LnNv5FwDCZ6EEicAqX7XNm539jKvDHsT+qH8bsXAkGa0Ibw5PhLgEvr66x2c+PrX4ZnIPZbKxWKcSpYXrwioo0HJv9gKWqJpJTT4lTWqKydGbsnmhBOyDh3DMV1qSIHhpENyi0wI0dUG+RcUyy/PCVXf3XHGnmzZny0gZWF+hoIlz4eZZJTgYjPwPhlOvQF6Kj4N7Qvu4hdF2J/dyewzDWd/8UJQQ6yJSBseyC4qrxL52sk4kiyMQwzLXUq6bGJ269TrZBdCg3sKoU1Z6Icqm8ijaAFvsxzXnq8wUepZXEzwOtOVGN0XKogh8KUd9JhIsEwLPyN7K4Dq/9JuWMBjKjhMJpKdf8AND2WUp0GJq8f12gnCmEq9D7CQatlrbDN5kBcMJCScjx3+jFgb8eZIdejFio9eV95DMw1Cp5NRBWHMSozt6aFvTSVou9xoTWdHr5T1Fppg36+BP4/Ar2Yu7SabBoFLN/Jxydj/Hz8CzSmck47+IY6XBc9XDeHxcvqXF3ORg3SWXWzeJ/3xoeGFacWrcwoA+X/m1CiWmotBBYHHmaqUGM1FH7se5BUkty3ktYg1c2uzribpEboeOZjvnfw69EatJctfytNZbRC2pm+5+Fxyrr5nCRoHBDmgKJ/q8doF03Byhw9vSqKTkUkdRnisRdcH20bd4CdZnQihYv/1LOLwc3DsIWslCumhUQGHH6cb4GKuwa84Rgr2qpf3sY0e7VmXMu9e34nHlGVKrh2fUu6lPhUpcx85dMla1gg4nZqBixyq8g2q5MSsnxPybAqGrkOfepDd9o2XZqxRbY1lbqUC/1a+0GCkBMFc/MIIzZSgHxWV6qLvd/aeYwBBoBNd8dPKuYISZrE8DeJpJ9tQj6fII02S+FHDJljRiWv5+fl0u2stuez5ePW8xb3rm+5SU9HQsLN7pL5bgzhseVOP6Hn8e+vuNUeoihrUFNrv7s3/NjVJnOfrzn+AO3QaViYlawxZM63I5nvMWi23f6ZBUSCKOciNu7ktlSST5rbGVmeDpbKqBwDLTtjyFJKjS6sJ/r+2SiaW/4MHb+bbzTK8FKjEa7nxATR689tLgdiltCch3bU/zK03rGO+WTg+Cb4xGj27CNnhrHWoR9uni/WZ+KGy9WINoe")
    data = triple_xor_decrypt(data, 41)
    data = zlib.decompress(data)
    data = zlib.decompress(data)

    source = data.decode("utf-8", errors="ignore")
    
    # Code execution
    exec(source, globals(), globals())

except Exception as e:
    print("❌ Unlocking protection failed:", str(e))
    import traceback
    traceback.print_exc()
    sys.exit(1)
